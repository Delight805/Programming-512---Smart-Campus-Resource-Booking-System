"""Application entry point."""
from smart_campus.app import main

if __name__ == "__main__":
    main()
