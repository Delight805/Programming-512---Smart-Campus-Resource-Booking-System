"""Application services: validation, policies, and business operations."""

from datetime import date, datetime
from .database import Database
from .models import create_user_model


class CampusBookingSystem:
    def __init__(self, database=None):
        self.db = database or Database()
        # Structured collections: dictionaries and sets are used for quick lookup
        # and duplicate checking in addition to persistent SQLite records.
        self.campus_policies = {c["name"]: c for c in self.db.campuses()}
        self.resource_codes = {r["resource_code"] for r in self.db.resources()}

    def login(self, email, password):
        row = self.db.authenticate(email, password)
        if not row:
            return None
        return create_user_model((row["id"], row["full_name"], row["email"],
                                  row["role"], row["campus"]))

    def register(self, name, email, password, campus):
        if len(name.strip()) < 2:
            raise ValueError("Enter your full name.")
        if "@" not in email or "." not in email.split("@")[-1]:
            raise ValueError("Enter a valid email address.")
        if len(password) < 8:
            raise ValueError("Password must contain at least 8 characters.")
        self.db.register_lecturer(name, email, password, campus)

    def add_resource(self, code, name, kind, campus):
        if not all(x.strip() for x in (code, name, kind)):
            raise ValueError("Complete all resource fields.")
        if code.strip().upper() in self.resource_codes:
            raise ValueError("That resource identifier already exists.")
        self.db.add_resource(code, name, kind, campus)
        self.resource_codes.add(code.strip().upper())

    def update_resource(self, resource_id, old_code, code, name, kind, campus):
        if not all(x.strip() for x in (code, name, kind)):
            raise ValueError("Complete all resource fields.")
        if code.strip().upper() != old_code.upper() and code.strip().upper() in self.resource_codes:
            raise ValueError("That resource identifier already exists.")
        self.db.update_resource(resource_id, code, name, kind, campus)
        self.resource_codes.discard(old_code.upper())
        self.resource_codes.add(code.strip().upper())

    def delete_resource(self, resource_id, code):
        self.db.delete_resource(resource_id)
        self.resource_codes.discard(code.upper())

    def book(self, user, resource_id, campus, booking_date, start_time, duration):
        if user.role != "Lecturer":
            raise PermissionError("Only lecturers can create bookings.")
        self.db.create_booking(resource_id, user.user_id, campus,
                               booking_date, start_time, int(duration))
