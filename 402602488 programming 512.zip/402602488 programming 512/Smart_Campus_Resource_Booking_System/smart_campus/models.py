"""Object-oriented user models demonstrating inheritance and encapsulation."""

class User:
    def __init__(self, user_id, full_name, email, role, campus=None):
        self._user_id = user_id
        self._full_name = full_name
        self._email = email
        self._role = role
        self._campus = campus

    @property
    def user_id(self):
        return self._user_id

    @property
    def full_name(self):
        return self._full_name

    @property
    def email(self):
        return self._email

    @property
    def role(self):
        return self._role

    @property
    def campus(self):
        return self._campus

    def can_manage_resources(self):
        return False

    def can_view_all_campuses(self):
        return False


class Lecturer(User):
    """Lecturers can make and manage their own bookings."""
    pass


class CampusAdministrator(User):
    """Campus administrators can manage resources at their campus."""
    def can_manage_resources(self):
        return True


class SystemOperator(User):
    """System operators have institution-wide reporting access."""
    def can_manage_resources(self):
        return True

    def can_view_all_campuses(self):
        return True


def create_user_model(row):
    user_id, full_name, email, role, campus = row
    classes = {
        "Lecturer": Lecturer,
        "Campus Administrator": CampusAdministrator,
        "System Operator": SystemOperator,
    }
    return classes.get(role, User)(user_id, full_name, email, role, campus)
