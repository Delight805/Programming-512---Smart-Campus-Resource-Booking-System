"""SQLite persistence layer. The database is created automatically."""

import hashlib
import os
import sqlite3
from pathlib import Path
from .config import CAMPUSES, DEFAULT_RESOURCES

DB_PATH = Path(__file__).resolve().parent.parent / "smart_campus.db"


def hash_password(password, salt=None):
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 150_000)
    return salt.hex() + "$" + digest.hex()


def verify_password(password, stored):
    try:
        salt_hex, _ = stored.split("$", 1)
        return hash_password(password, bytes.fromhex(salt_hex)) == stored
    except (ValueError, AttributeError):
        return False


class Database:
    def __init__(self, path=DB_PATH):
        self.path = str(path)
        self.initialize()

    def connect(self):
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def initialize(self):
        with self.connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    full_name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN
                      ('Lecturer','Campus Administrator','System Operator')),
                    campus TEXT
                );
                CREATE TABLE IF NOT EXISTS campuses (
                    name TEXT PRIMARY KEY,
                    max_duration INTEGER NOT NULL,
                    start_hour INTEGER NOT NULL,
                    end_hour INTEGER NOT NULL,
                    policy TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS resources (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    resource_code TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    name TEXT NOT NULL,
                    resource_type TEXT NOT NULL,
                    campus TEXT NOT NULL REFERENCES campuses(name)
                );
                CREATE TABLE IF NOT EXISTS bookings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    resource_id INTEGER NOT NULL REFERENCES resources(id),
                    lecturer_id INTEGER NOT NULL REFERENCES users(id),
                    campus TEXT NOT NULL REFERENCES campuses(name),
                    booking_date TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    duration INTEGER NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Active'
                      CHECK(status IN ('Active','Cancelled')),
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
            """)
            for name, policy in CAMPUSES.items():
                conn.execute("""
                    INSERT OR IGNORE INTO campuses
                    (name, max_duration, start_hour, end_hour, policy)
                    VALUES (?, ?, ?, ?, ?)
                """, (name, policy["max_duration"], policy["start_hour"],
                      policy["end_hour"], policy["policy"]))
            count = conn.execute("SELECT COUNT(*) FROM resources").fetchone()[0]
            if count == 0:
                conn.executemany("""
                    INSERT OR IGNORE INTO resources
                    (resource_code, name, resource_type, campus)
                    VALUES (?, ?, ?, ?)
                """, DEFAULT_RESOURCES)
            self._seed_demo_users(conn)

    def _seed_demo_users(self, conn):
        demos = [
            ("Campus Administrator", "admin@richfield.ac.za", "Admin123!", "Campus Administrator", "Pretoria"),
            ("System Operator", "operator@richfield.ac.za", "Operator123!", "System Operator", None),
        ]
        for name, email, password, role, campus in demos:
            conn.execute("""
                INSERT OR IGNORE INTO users(full_name,email,password_hash,role,campus)
                VALUES(?,?,?,?,?)
            """, (name, email, hash_password(password), role, campus))

    def authenticate(self, email, password):
        with self.connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE email = ? COLLATE NOCASE",
                               (email.strip(),)).fetchone()
        if row and verify_password(password, row["password_hash"]):
            return dict(row)
        return None

    def register_lecturer(self, full_name, email, password, campus):
        with self.connect() as conn:
            conn.execute("""
                INSERT INTO users(full_name,email,password_hash,role,campus)
                VALUES(?,?,?,'Lecturer',?)
            """, (full_name.strip(), email.strip().lower(), hash_password(password), campus))

    def campuses(self):
        with self.connect() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM campuses ORDER BY name")]

    def resources(self, campus=None):
        with self.connect() as conn:
            if campus:
                rows = conn.execute("SELECT * FROM resources WHERE campus=? ORDER BY name",
                                    (campus,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM resources ORDER BY campus,name").fetchall()
            return [dict(r) for r in rows]

    def add_resource(self, code, name, kind, campus):
        with self.connect() as conn:
            conn.execute("""INSERT INTO resources(resource_code,name,resource_type,campus)
                            VALUES(?,?,?,?)""", (code.strip().upper(), name.strip(), kind.strip(), campus))

    def update_resource(self, resource_id, code, name, kind, campus):
        with self.connect() as conn:
            conn.execute("""UPDATE resources SET resource_code=?,name=?,resource_type=?,campus=?
                            WHERE id=?""",
                         (code.strip().upper(), name.strip(), kind.strip(), campus, resource_id))

    def delete_resource(self, resource_id):
        with self.connect() as conn:
            conn.execute("DELETE FROM resources WHERE id=?", (resource_id,))

    def create_booking(self, resource_id, lecturer_id, campus, date, start, duration):
        with self.connect() as conn:
            policy = conn.execute("SELECT * FROM campuses WHERE name=?", (campus,)).fetchone()
            if not policy:
                raise ValueError("Please select a valid campus.")
            if duration < 1 or duration > policy["max_duration"]:
                raise ValueError(f"{campus} allows bookings from 1 to {policy['max_duration']} hours.")
            try:
                start_hour, start_minute = map(int, start.split(":"))
                from datetime import datetime
                datetime.strptime(date, "%Y-%m-%d")
                if start_minute not in (0, 30):
                    raise ValueError("Start time must use 00 or 30 minutes.")
                if start_hour < policy["start_hour"] or start_hour >= policy["end_hour"]:
                    raise ValueError(f"Bookings must start between {policy['start_hour']:02d}:00 and {policy['end_hour']-1:02d}:30.")
                end_minutes = start_hour * 60 + start_minute + duration * 60
                if end_minutes > policy["end_hour"] * 60:
                    raise ValueError("The booking ends outside this campus's permitted hours.")
            except (ValueError, TypeError):
                raise ValueError("Enter a valid date (YYYY-MM-DD) and time (HH:MM).")
            from datetime import date as date_type
            if date_type.fromisoformat(date) < date_type.today():
                raise ValueError("You cannot make a booking for a date in the past.")
            start_minutes = start_hour * 60 + start_minute
            end_minutes = start_minutes + duration * 60
            active = conn.execute("""
                SELECT start_time,duration FROM bookings
                WHERE resource_id=? AND booking_date=? AND status='Active'
            """, (resource_id, date)).fetchall()
            for item in active:
                old_h, old_m = map(int, item["start_time"].split(":"))
                old_start = old_h * 60 + old_m
                old_end = old_start + item["duration"] * 60
                if start_minutes < old_end and old_start < end_minutes:
                    raise ValueError("This resource is already booked during that time.")
            conn.execute("""
                INSERT INTO bookings(resource_id,lecturer_id,campus,booking_date,start_time,duration)
                VALUES(?,?,?,?,?,?)
            """, (resource_id, lecturer_id, campus, date, start, duration))

    def bookings(self, campus=None, lecturer_id=None, active_only=False):
        sql = """
            SELECT b.*, r.resource_code, r.name AS resource_name, r.resource_type,
                   u.full_name AS lecturer_name, u.email AS lecturer_email
            FROM bookings b
            JOIN resources r ON r.id=b.resource_id
            JOIN users u ON u.id=b.lecturer_id
            WHERE 1=1
        """
        params = []
        if campus:
            sql += " AND b.campus=?"; params.append(campus)
        if lecturer_id is not None:
            sql += " AND b.lecturer_id=?"; params.append(lecturer_id)
        if active_only:
            sql += " AND b.status='Active'"
        sql += " ORDER BY b.booking_date DESC,b.start_time"
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(sql, params)]

    def cancel_booking(self, booking_id, lecturer_id):
        with self.connect() as conn:
            row = conn.execute("""SELECT booking_date,status FROM bookings
                                  WHERE id=? AND lecturer_id=?""",
                               (booking_id, lecturer_id)).fetchone()
            if not row:
                raise ValueError("Booking not found or you do not have permission to cancel it.")
            from datetime import date
            if row["status"] != "Active" or row["booking_date"] < date.today().isoformat():
                raise ValueError("Only active future bookings can be cancelled.")
            conn.execute("UPDATE bookings SET status='Cancelled' WHERE id=?", (booking_id,))

    def campus_report(self, campus=None):
        with self.connect() as conn:
            where = "WHERE b.status='Active'"
            params = []
            if campus:
                where += " AND b.campus=?"; params.append(campus)
            total = conn.execute(f"SELECT COUNT(*) FROM bookings b {where}", params).fetchone()[0]
            avg = conn.execute(f"SELECT AVG(b.duration) FROM bookings b {where}", params).fetchone()[0] or 0
            popular = conn.execute(f"""
                SELECT r.name, COUNT(*) AS uses FROM bookings b
                JOIN resources r ON r.id=b.resource_id {where}
                GROUP BY r.id ORDER BY uses DESC LIMIT 5
            """, params).fetchall()
            by_campus = conn.execute("""
                SELECT c.name, COUNT(b.id) AS total,
                       COALESCE(AVG(b.duration),0) AS average_duration
                FROM campuses c LEFT JOIN bookings b
                  ON b.campus=c.name AND b.status='Active'
                GROUP BY c.name ORDER BY c.name
            """).fetchall()
            return {"total": total, "average": avg,
                    "popular": [dict(x) for x in popular],
                    "campuses": [dict(x) for x in by_campus]}
