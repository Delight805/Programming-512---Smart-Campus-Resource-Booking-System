"""Configuration and campus-specific booking policies."""

CAMPUSES = {
    "Pretoria": {
        "max_duration": 3,
        "start_hour": 8,
        "end_hour": 17,
        "policy": "Maximum 3 hours per booking; bookings allowed 08:00–17:00.",
    },
    "Johannesburg": {
        "max_duration": 2,
        "start_hour": 9,
        "end_hour": 16,
        "policy": "Maximum 2 hours per booking; bookings allowed 09:00–16:00.",
    },
    "Durban": {
        "max_duration": 4,
        "start_hour": 8,
        "end_hour": 18,
        "policy": "Maximum 4 hours per booking; bookings allowed 08:00–18:00.",
    },
}

DEFAULT_RESOURCES = [
    ("PRE-LAB-01", "Computer Laboratory 1", "Computer Laboratory", "Pretoria"),
    ("PRE-PROJ-01", "Multimedia Projector 1", "Projector", "Pretoria"),
    ("PRE-SEM-01", "Seminar Room 1", "Seminar Room", "Pretoria"),
    ("JHB-LAB-01", "Computer Laboratory 1", "Computer Laboratory", "Johannesburg"),
    ("JHB-PROJ-01", "Presentation Projector", "Projector", "Johannesburg"),
    ("JHB-SEM-01", "Seminar Room 1", "Seminar Room", "Johannesburg"),
    ("DBN-LAB-01", "Computer Laboratory 1", "Computer Laboratory", "Durban"),
    ("DBN-PROJ-01", "Multimedia Projector 1", "Projector", "Durban"),
    ("DBN-SEM-01", "Seminar Room 1", "Seminar Room", "Durban"),
]
