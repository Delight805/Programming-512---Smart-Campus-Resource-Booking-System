"""Tkinter graphical user interface for the Smart Campus Resource Booking System."""

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from .services import CampusBookingSystem


class SmartCampusApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Richfield | Smart Campus Resource Booking System")
        self.root.geometry("1120x720")
        self.root.minsize(900, 600)
        self.system = CampusBookingSystem()
        self.user = None
        self.active_campus = None
        self.selected_resource = None
        self._style()
        self.show_login()

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Heading.TLabel", font=("Segoe UI", 13, "bold"))
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def header(self, title, subtitle=""):
        top = ttk.Frame(self.root, padding=(22, 18))
        top.pack(fill="x")
        ttk.Label(top, text=title, style="Title.TLabel").pack(anchor="w")
        if subtitle:
            ttk.Label(top, text=subtitle).pack(anchor="w", pady=(4, 0))

    def show_login(self):
        self.clear()
        self.header("Smart Campus Resource Booking System",
                    "Richfield Graduate Institution | Secure sign in")
        panel = ttk.Frame(self.root, padding=30)
        panel.pack(pady=20)
        ttk.Label(panel, text="Welcome back", style="Heading.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 18))
        ttk.Label(panel, text="Email address").grid(row=1, column=0, sticky="w", pady=7)
        email = ttk.Entry(panel, width=38)
        email.grid(row=1, column=1, padx=10, pady=7)
        ttk.Label(panel, text="Password").grid(row=2, column=0, sticky="w", pady=7)
        password = ttk.Entry(panel, width=38, show="•")
        password.grid(row=2, column=1, padx=10, pady=7)
        ttk.Button(panel, text="Log in", style="Primary.TButton",
                   command=lambda: self.login(email.get(), password.get())).grid(row=3, column=1, sticky="ew", pady=14)
        ttk.Button(panel, text="Register as a lecturer", command=self.show_register).grid(row=4, column=1, sticky="ew")
        demo = ("Demo administrator: admin@richfield.ac.za / Admin123!\n"
                "Demo operator: operator@richfield.ac.za / Operator123!")
        ttk.Label(self.root, text=demo, justify="center").pack(pady=12)
        ttk.Label(self.root, text="For demonstration and assessment purposes. Change demo passwords before real deployment.",
                  foreground="gray").pack(side="bottom", pady=12)
        email.focus_set()
        password.bind("<Return>", lambda _e: self.login(email.get(), password.get()))

    def login(self, email, password):
        user = self.system.login(email, password)
        if not user:
            messagebox.showerror("Login failed", "Incorrect email address or password.")
            return
        self.user = user
        self.active_campus = user.campus if user.role == "Campus Administrator" else "Pretoria"
        self.show_dashboard()

    def show_register(self):
        self.clear()
        self.header("Lecturer registration", "Create an account to book campus resources.")
        form = ttk.Frame(self.root, padding=30)
        form.pack(pady=10)
        fields = {}
        for i, label in enumerate(("Full name", "Email", "Password")):
            ttk.Label(form, text=label).grid(row=i, column=0, sticky="w", pady=8)
            entry = ttk.Entry(form, width=38, show="•" if label == "Password" else "")
            entry.grid(row=i, column=1, padx=12, pady=8)
            fields[label] = entry
        ttk.Label(form, text="Home campus").grid(row=3, column=0, sticky="w", pady=8)
        campus = ttk.Combobox(form, values=list(self.system.campus_policies), state="readonly", width=35)
        campus.grid(row=3, column=1, padx=12, pady=8)
        campus.current(0)
        def submit():
            try:
                self.system.register(fields["Full name"].get(), fields["Email"].get(),
                                     fields["Password"].get(), campus.get())
                messagebox.showinfo("Registration successful", "Your lecturer account has been created. You can now log in.")
                self.show_login()
            except Exception as exc:
                messagebox.showerror("Registration error", str(exc))
        ttk.Button(form, text="Create account", style="Primary.TButton", command=submit).grid(row=4, column=1, sticky="ew", pady=15)
        ttk.Button(form, text="Back to login", command=self.show_login).grid(row=5, column=1, sticky="ew")

    def show_dashboard(self):
        self.clear()
        campus_label = self.active_campus or "All campuses"
        self.header("Smart Campus Dashboard",
                    f"Signed in: {self.user.full_name}  |  Role: {self.user.role}  |  Active campus: {campus_label}")
        bar = ttk.Frame(self.root, padding=(20, 0, 20, 12))
        bar.pack(fill="x")
        ttk.Label(bar, text="Working campus:").pack(side="left")
        self.campus_var = tk.StringVar(value=self.active_campus or "Pretoria")
        campuses = list(self.system.campus_policies)
        if self.user.role == "Campus Administrator":
            campuses = [self.user.campus]
        self.campus_combo = ttk.Combobox(bar, textvariable=self.campus_var, values=campuses, state="readonly", width=20)
        self.campus_combo.pack(side="left", padx=8)
        self.campus_combo.bind("<<ComboboxSelected>>", self.change_campus)
        ttk.Button(bar, text="Refresh", command=self.show_dashboard).pack(side="left", padx=8)
        ttk.Button(bar, text="Log out", command=self.logout).pack(side="right")
        self.active_campus = self.campus_var.get()
        policy = self.system.campus_policies[self.active_campus]
        ttk.Label(self.root, text=f"Current booking policy: {policy['policy']}",
                  padding=(22, 4), foreground="#245b84").pack(anchor="w")
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=20, pady=12)

        if self.user.role == "Lecturer":
            book_tab = ttk.Frame(notebook, padding=14)
            mine_tab = ttk.Frame(notebook, padding=14)
            notebook.add(book_tab, text="Book a resource")
            notebook.add(mine_tab, text="My bookings")
            self.build_booking_tab(book_tab)
            self.build_my_bookings(mine_tab)
        elif self.user.role == "Campus Administrator":
            resource_tab = ttk.Frame(notebook, padding=14)
            bookings_tab = ttk.Frame(notebook, padding=14)
            report_tab = ttk.Frame(notebook, padding=14)
            notebook.add(resource_tab, text="Manage resources")
            notebook.add(bookings_tab, text="Campus bookings")
            notebook.add(report_tab, text="Usage report")
            self.build_resource_tab(resource_tab)
            self.build_all_bookings(bookings_tab, campus_only=True)
            self.build_report_tab(report_tab, campus_only=True)
        else:
            all_tab = ttk.Frame(notebook, padding=14)
            report_tab = ttk.Frame(notebook, padding=14)
            resources_tab = ttk.Frame(notebook, padding=14)
            notebook.add(all_tab, text="All bookings")
            notebook.add(report_tab, text="Cross-campus reports")
            notebook.add(resources_tab, text="All resources")
            self.build_all_bookings(all_tab, campus_only=False)
            self.build_report_tab(report_tab, campus_only=False)
            self.build_resource_overview(resources_tab)

    def change_campus(self, _event=None):
        self.active_campus = self.campus_var.get()
        self.show_dashboard()

    def logout(self):
        self.user = None
        self.active_campus = None
        self.show_login()

    def make_tree(self, parent, columns, headings, widths=None):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, pady=8)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        for i, col in enumerate(columns):
            tree.heading(col, text=headings[i])
            tree.column(col, width=(widths[i] if widths else 130), anchor="w")
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=yscroll.set)
        tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")
        return tree

    def build_booking_tab(self, parent):
        ttk.Label(parent, text="Available resources", style="Heading.TLabel").pack(anchor="w")
        tree = self.make_tree(parent, ("id","code","name","type","campus"),
                              ("ID","Resource code","Resource","Type","Campus"),
                              (50,130,230,170,120))
        def load():
            tree.delete(*tree.get_children())
            for r in self.system.db.resources(self.active_campus):
                tree.insert("", "end", values=(r["id"],r["resource_code"],r["name"],r["resource_type"],r["campus"]))
        load()
        form = ttk.LabelFrame(parent, text="Booking details", padding=12)
        form.pack(fill="x", pady=10)
        ttk.Label(form, text="Booking date (YYYY-MM-DD)").grid(row=0,column=0,sticky="w",padx=5,pady=5)
        date_entry = ttk.Entry(form, width=18); date_entry.insert(0, date.today().isoformat())
        date_entry.grid(row=0,column=1,padx=5,pady=5)
        ttk.Label(form, text="Start time (HH:MM)").grid(row=0,column=2,sticky="w",padx=5,pady=5)
        time_entry = ttk.Entry(form, width=12); time_entry.insert(0,"09:00")
        time_entry.grid(row=0,column=3,padx=5,pady=5)
        ttk.Label(form, text="Duration (hours)").grid(row=0,column=4,sticky="w",padx=5,pady=5)
        duration = ttk.Spinbox(form, from_=1, to=self.system.campus_policies[self.active_campus]["max_duration"], width=5)
        duration.set(1); duration.grid(row=0,column=5,padx=5,pady=5)
        def book():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Select a resource", "Select a resource from the list first.")
                return
            values = tree.item(selected[0], "values")
            try:
                self.system.book(self.user, int(values[0]), self.active_campus,
                                 date_entry.get().strip(), time_entry.get().strip(),
                                 int(duration.get()))
                messagebox.showinfo("Booking successful", "Your resource has been booked.")
                load()
            except Exception as exc:
                messagebox.showerror("Booking rejected", str(exc))
        ttk.Button(form, text="Confirm booking", style="Primary.TButton", command=book).grid(row=0,column=6,padx=10)

    def build_my_bookings(self, parent):
        tree = self.make_tree(parent, ("id","resource","campus","date","start","duration","status"),
                              ("Booking ID","Resource","Campus","Date","Start","Hours","Status"),
                              (80,200,120,110,80,70,100))
        def load():
            tree.delete(*tree.get_children())
            for b in self.system.db.bookings(lecturer_id=self.user.user_id):
                tree.insert("", "end", values=(b["id"],b["resource_name"],b["campus"],b["booking_date"],
                                               b["start_time"],b["duration"],b["status"]))
        load()
        def cancel():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Select booking", "Select a booking to cancel.")
                return
            booking_id = int(tree.item(selected[0],"values")[0])
            if messagebox.askyesno("Confirm cancellation", "Cancel this future booking?"):
                try:
                    self.system.db.cancel_booking(booking_id, self.user.user_id)
                    load()
                    messagebox.showinfo("Cancelled", "The booking has been cancelled.")
                except Exception as exc:
                    messagebox.showerror("Cancellation error", str(exc))
        ttk.Button(parent, text="Cancel selected future booking", command=cancel).pack(anchor="e", pady=5)

    def build_resource_tab(self, parent):
        tree = self.make_tree(parent, ("id","code","name","type","campus"),
                              ("ID","Resource code","Resource","Type","Campus"),
                              (55,140,240,180,130))
        def load():
            tree.delete(*tree.get_children())
            for r in self.system.db.resources(self.active_campus):
                tree.insert("", "end", values=(r["id"],r["resource_code"],r["name"],r["resource_type"],r["campus"]))
        load()
        form = ttk.LabelFrame(parent, text="Add or update resource", padding=10)
        form.pack(fill="x", pady=8)
        entries = {}
        for i, (label, default) in enumerate((("Resource code",""),("Resource name",""),("Resource type",""))):
            ttk.Label(form,text=label).grid(row=0,column=i*2,sticky="w",padx=4)
            e=ttk.Entry(form,width=22); e.insert(0,default); e.grid(row=0,column=i*2+1,padx=4,pady=5)
            entries[label]=e
        selected_id = {"value": None, "old_code": None}
        def choose(_event=None):
            sel=tree.selection()
            if not sel: return
            v=tree.item(sel[0],"values")
            selected_id["value"]=int(v[0]); selected_id["old_code"]=v[1]
            entries["Resource code"].delete(0,"end"); entries["Resource code"].insert(0,v[1])
            entries["Resource name"].delete(0,"end"); entries["Resource name"].insert(0,v[2])
            entries["Resource type"].delete(0,"end"); entries["Resource type"].insert(0,v[3])
        tree.bind("<<TreeviewSelect>>",choose)
        def add():
            try:
                self.system.add_resource(entries["Resource code"].get(),entries["Resource name"].get(),
                                         entries["Resource type"].get(),self.active_campus)
                load(); messagebox.showinfo("Saved","Resource added successfully.")
            except Exception as exc: messagebox.showerror("Resource error",str(exc))
        def update():
            if selected_id["value"] is None:
                messagebox.showwarning("Select resource","Select a resource to update."); return
            try:
                self.system.update_resource(selected_id["value"],selected_id["old_code"],
                    entries["Resource code"].get(),entries["Resource name"].get(),
                    entries["Resource type"].get(),self.active_campus)
                selected_id["value"]=None; load(); messagebox.showinfo("Updated","Resource updated.")
            except Exception as exc: messagebox.showerror("Resource error",str(exc))
        def delete():
            if selected_id["value"] is None:
                messagebox.showwarning("Select resource","Select a resource to remove."); return
            if messagebox.askyesno("Confirm removal","Remove the selected resource?"):
                try:
                    self.system.delete_resource(selected_id["value"],selected_id["old_code"])
                    selected_id["value"]=None; load()
                except Exception as exc: messagebox.showerror("Cannot remove resource",str(exc))
        actions=ttk.Frame(form); actions.grid(row=1,column=0,columnspan=6,sticky="e",pady=6)
        ttk.Button(actions,text="Add resource",command=add).pack(side="left",padx=4)
        ttk.Button(actions,text="Update selected",command=update).pack(side="left",padx=4)
        ttk.Button(actions,text="Remove selected",command=delete).pack(side="left",padx=4)

    def build_all_bookings(self, parent, campus_only):
        campus = self.active_campus if campus_only else None
        tree = self.make_tree(parent, ("id","lecturer","resource","campus","date","start","duration","status"),
                              ("ID","Lecturer","Resource","Campus","Date","Start","Hours","Status"),
                              (50,150,180,110,100,75,65,90))
        for b in self.system.db.bookings(campus=campus):
            tree.insert("", "end", values=(b["id"],b["lecturer_name"],b["resource_name"],b["campus"],
                                           b["booking_date"],b["start_time"],b["duration"],b["status"]))

    def build_report_tab(self, parent, campus_only):
        report = self.system.db.campus_report(self.active_campus if campus_only else None)
        summary = ttk.Frame(parent); summary.pack(fill="x", pady=12)
        ttk.Label(summary,text=f"Active bookings: {report['total']}",style="Heading.TLabel").pack(anchor="w",pady=4)
        ttk.Label(summary,text=f"Average booking duration: {report['average']:.2f} hours").pack(anchor="w",pady=4)
        ttk.Label(parent,text="Most frequently used resources",style="Heading.TLabel").pack(anchor="w",pady=(15,4))
        for item in report["popular"]:
            ttk.Label(parent,text=f"• {item['name']} — {item['uses']} booking(s)").pack(anchor="w",pady=2)
        if not campus_only:
            ttk.Label(parent,text="Campus comparison",style="Heading.TLabel").pack(anchor="w",pady=(18,4))
            tree=self.make_tree(parent,("campus","total","average"),
                                ("Campus","Active bookings","Average duration (hours)"),(200,180,220))
            for row in report["campuses"]:
                tree.insert("","end",values=(row["name"],row["total"],f"{row['average_duration']:.2f}"))

    def build_resource_overview(self, parent):
        tree=self.make_tree(parent,("code","name","type","campus"),
                            ("Resource code","Resource","Type","Campus"),(160,260,200,160))
        for r in self.system.db.resources():
            tree.insert("","end",values=(r["resource_code"],r["name"],r["resource_type"],r["campus"]))


def main():
    root = tk.Tk()
    SmartCampusApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
