# Smart Campus Resource Booking System

A Python desktop application for Richfield Graduate Institution. It uses Tkinter
for the graphical interface, SQLite for persistent storage, and object-oriented
programming for role-based access.

## Requirements
- Python 3.10 or later
- Tkinter (included with most standard Python installations)
- No third-party Python packages are required

## Run the application
1. Extract the ZIP file.
2. Open a terminal or Command Prompt in the extracted project folder.
3. Run:

   ```bash
   python main.py
   ```

The SQLite database (`smart_campus.db`) is created automatically the first time
the application runs. Keep this file to retain users, resources and bookings.

## Demonstration accounts
- Campus Administrator
  - Email: `admin@richfield.ac.za`
  - Password: `Admin123!`
  - Campus: Pretoria
- System Operator
  - Email: `operator@richfield.ac.za`
  - Password: `Operator123!`

Lecturers can register their own accounts from the login screen.

**Security note:** These demonstration credentials are provided for assessment
demonstration only. Change or remove them before any real deployment.

## Included features
- Lecturer registration and login
- Role-based lecturer, campus administrator and system operator access
- Three campuses with different booking policies
- Resource registration, editing and removal
- Unique resource identifiers and duplicate detection
- Booking date, time and duration validation
- Prevention of overlapping bookings
- Lecturer booking history and cancellation of future bookings
- Campus usage reports and cross-campus comparisons
- SQLite persistence between program executions
- Password hashing using PBKDF2-HMAC-SHA256

## Project structure

```text
Smart_Campus_Resource_Booking_System/
├── main.py
├── README.md
└── smart_campus/
    ├── __init__.py
    ├── app.py
    ├── config.py
    ├── database.py
    ├── models.py
    └── services.py
```

## Design notes
- `User` is the base class. `Lecturer`, `CampusAdministrator` and
  `SystemOperator` inherit from it.
- Encapsulation is demonstrated through private-style user attributes and
  read-only properties.
- Lists, dictionaries and sets are used to organise campuses, policies and
  resource identifiers.
- SQLite stores accounts, campuses, resources and bookings.
- Campus booking rules are stored separately from the booking interface so
  that policies can be changed or new campuses added with limited changes.

## Important limitations for a production system
This is an educational demonstration. It does not include email verification,
password reset, network deployment, audit logging, or administrator account
creation from the GUI. The seeded administrator account is assigned to Pretoria.
